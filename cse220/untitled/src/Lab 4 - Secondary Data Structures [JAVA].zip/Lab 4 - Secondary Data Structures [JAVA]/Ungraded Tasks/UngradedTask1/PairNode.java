public class PairNode {
    
    String key;
    Integer value;
    PairNode next;

    public PairNode( String k, Integer v ){
        // TO DO
    }
    
}
