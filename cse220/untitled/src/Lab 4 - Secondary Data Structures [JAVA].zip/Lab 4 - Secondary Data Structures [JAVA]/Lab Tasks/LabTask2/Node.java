//DO NOT CHANGE THIS CLASS
public class Node {
    int elem;
    Node next;
    //DO NOT CHANGE THIS CONSTRUCTOR
    public Node(int elem, Node next) {
        this.elem = elem;
        this.next = next;
    }
}